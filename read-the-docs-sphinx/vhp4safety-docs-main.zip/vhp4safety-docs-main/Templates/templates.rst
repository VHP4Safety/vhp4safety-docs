Data collection templates
================================================

All data collection templates can be downloaded below:
The orginal templates can also be found in the Github repo `https://github.com/VHP4Safety/data-collection-templates <https://github.com/VHP4Safety/data-collection-templates>`_

* Basic template: |Book1.xlsx| (published as `Book1.xlsx`_)

.. |Book1.xlsx| replace::
    :download:`Book1.xlsx <Book1.xlsx>`
.. _`Book1.xlsx`:
    https://github.com/VHP4Safety/data-collection-templates/raw/main/Book1.xlsx